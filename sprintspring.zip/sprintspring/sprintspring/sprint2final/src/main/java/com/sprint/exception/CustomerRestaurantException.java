package com.sprint.exception;

public class CustomerRestaurantException extends Exception{
	private static final long serialVersionUID = 1L;

	public CustomerRestaurantException(String message)	{
		super(message);
	}
}
