package com.sprint.service;

import java.util.HashMap;
import java.util.List;

import com.sprint.beans.Menu;

public interface MenuService {

	public List<String> getMenu();
	
}
